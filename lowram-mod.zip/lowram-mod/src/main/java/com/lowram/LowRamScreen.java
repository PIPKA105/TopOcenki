package com.lowram;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class LowRamScreen extends Screen {

    private static final int BW = 120, GAP = 4, COLS = 3;
    private final Screen parent;
    private int x0;

    public LowRamScreen(Screen parent) {
        super(Text.literal("LowRam — оптимизация"));
        this.parent = parent;
    }

    private static int next(int v, int[] opts) {
        for (int i = 0; i < opts.length; i++) if (opts[i] == v) return opts[(i + 1) % opts.length];
        return opts[0];
    }

    private static double nextD(double v, double[] opts) {
        for (int i = 0; i < opts.length; i++) if (Math.abs(opts[i] - v) < 0.01) return opts[(i + 1) % opts.length];
        return opts[0];
    }

    private void changed() {
        LowRamConfig.save();
        LowRamMod.apply(client);
        clearAndInit();
    }

    private void addBtn(int idx, String text, ButtonWidget.PressAction action) {
        int col = idx % COLS, row = idx / COLS;
        int x = x0 + col * (BW + GAP);
        int y = 40 + row * 24;
        addDrawableChild(ButtonWidget.builder(Text.literal(text), action).dimensions(x, y, BW, 20).build());
    }

    @Override
    protected void init() {
        x0 = (width - (COLS * BW + (COLS - 1) * GAP)) / 2;

        addBtn(0, "Пресет: Баланс", b -> { LowRamConfig.presetBalanced(); changed(); });
        addBtn(1, "Пресет: Экстрим", b -> { LowRamConfig.presetExtreme(); changed(); });
        addBtn(2, "Очистить память", b -> { System.gc(); });

        addBtn(3, "Прорисовка: " + LowRamConfig.viewDistance, b -> {
            LowRamConfig.viewDistance = next(LowRamConfig.viewDistance, new int[]{2, 3, 4, 6, 8, 10, 12});
            changed();
        });
        addBtn(4, "Симуляция: " + LowRamConfig.simDistance, b -> {
            LowRamConfig.simDistance = next(LowRamConfig.simDistance, new int[]{5, 6, 8, 10, 12});
            changed();
        });
        addBtn(5, "Сущности: " + (int) Math.round(LowRamConfig.entityDistance * 100) + "%", b -> {
            LowRamConfig.entityDistance = nextD(LowRamConfig.entityDistance, new double[]{0.5, 0.75, 1.0});
            changed();
        });

        String[] pn = {"Все", "Меньше", "Минимум"};
        addBtn(6, "Частицы: " + pn[LowRamConfig.particles], b -> {
            LowRamConfig.particles = (LowRamConfig.particles + 1) % 3;
            changed();
        });
        addBtn(7, "Макс FPS: " + LowRamConfig.maxFps, b -> {
            LowRamConfig.maxFps = next(LowRamConfig.maxFps, new int[]{30, 60, 90, 120});
            changed();
        });
        addBtn(8, "Быстрая графика: " + (LowRamConfig.fastGraphics ? "да" : "нет"), b -> {
            LowRamConfig.fastGraphics = !LowRamConfig.fastGraphics;
            changed();
        });

        addBtn(9, "Облака выкл: " + (LowRamConfig.cloudsOff ? "да" : "нет"), b -> {
            LowRamConfig.cloudsOff = !LowRamConfig.cloudsOff;
            changed();
        });
        addBtn(10, "Тени сущностей выкл: " + (LowRamConfig.entityShadowsOff ? "да" : "нет"), b -> {
            LowRamConfig.entityShadowsOff = !LowRamConfig.entityShadowsOff;
            changed();
        });
        addBtn(11, "Авто-очистка: " + (LowRamConfig.autoGc ? "да" : "нет"), b -> {
            LowRamConfig.autoGc = !LowRamConfig.autoGc;
            changed();
        });

        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(width / 2 - 100, height - 28, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);

        Runtime rt = Runtime.getRuntime();
        long used = (rt.totalMemory() - rt.freeMemory()) / 1048576L;
        long max = rt.maxMemory() / 1048576L;
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Память Java: " + used + " МБ из " + max + " МБ"), width / 2, 26, 0xAAAAAA);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Очистка идёт только в меню и на паузе — без микро-фризов"),
                width / 2, height - 44, 0x888888);
    }

    @Override
    public void close() {
        client.setScreen(parent);
    }
}
