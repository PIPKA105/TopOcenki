package com.lowram;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

public class LowRamMod implements ClientModInitializer {

    // Максимальные значения (можно менять)
    private static final int MAX_VIEW_DISTANCE = 6;
    private static final int MAX_SIMULATION_DISTANCE = 5;
    private static final double MAX_ENTITY_DISTANCE = 0.5;
    private static final int MAX_FPS = 60;

    // Проверка памяти раз в 5 минут (6000 тиков), чистка если занято > 75%
    private static final int CHECK_INTERVAL_TICKS = 6000;
    private static final double GC_THRESHOLD = 0.75;

    private int tickCounter = 0;

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(this::applyLowSettings);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> applyLowSettings(client));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> System.gc());
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);
    }

    private void applyLowSettings(MinecraftClient client) {
        GameOptions o = client.options;
        if (o == null) return;

        if (o.getViewDistance().getValue() > MAX_VIEW_DISTANCE)
            o.getViewDistance().setValue(MAX_VIEW_DISTANCE);
        if (o.getSimulationDistance().getValue() > MAX_SIMULATION_DISTANCE)
            o.getSimulationDistance().setValue(MAX_SIMULATION_DISTANCE);
        if (o.getEntityDistanceScaling().getValue() > MAX_ENTITY_DISTANCE)
            o.getEntityDistanceScaling().setValue(MAX_ENTITY_DISTANCE);
        if (o.getMaxFps().getValue() > MAX_FPS)
            o.getMaxFps().setValue(MAX_FPS);

        o.getParticles().setValue(ParticlesMode.MINIMAL);
        o.getMipmapLevels().setValue(0);
        o.getBiomeBlendRadius().setValue(0);
    }

    private void onTick(MinecraftClient client) {
        if (++tickCounter < CHECK_INTERVAL_TICKS) return;
        tickCounter = 0;

        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        if ((double) used / rt.maxMemory() > GC_THRESHOLD) {
            System.gc();
        }
    }
}
