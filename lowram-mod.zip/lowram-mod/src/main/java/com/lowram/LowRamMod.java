package com.lowram;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.text.Text;

public class LowRamMod implements ClientModInitializer {

    private int tickCounter = 0;
    private long lastGc = 0;

    @Override
    public void onInitializeClient() {
        LowRamConfig.load();

        ClientLifecycleEvents.CLIENT_STARTED.register(LowRamMod::apply);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> apply(client));
        // Очистка при выходе из мира: игра в этот момент и так грузится, фриза не видно
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> System.gc());
        ClientTickEvents.END_CLIENT_TICK.register(this::onTick);

        // Кнопка в главном меню
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen) {
                Screens.getButtons(screen).add(
                        ButtonWidget.builder(Text.literal("Оптимизация LowRam"),
                                        b -> client.setScreen(new LowRamScreen(screen)))
                                .dimensions(4, 4, 140, 20)
                                .build());
            }
        });
    }

    public static void apply(MinecraftClient client) {
        GameOptions o = client.options;
        if (o == null) return;

        o.getViewDistance().setValue(LowRamConfig.viewDistance);
        o.getSimulationDistance().setValue(LowRamConfig.simDistance);
        o.getEntityDistanceScaling().setValue(LowRamConfig.entityDistance);
        o.getMaxFps().setValue(LowRamConfig.maxFps);

        ParticlesMode[] modes = {ParticlesMode.ALL, ParticlesMode.DECREASED, ParticlesMode.MINIMAL};
        o.getParticles().setValue(modes[Math.max(0, Math.min(2, LowRamConfig.particles))]);

        o.getGraphicsMode().setValue(LowRamConfig.fastGraphics ? GraphicsMode.FAST : GraphicsMode.FANCY);
        o.getCloudRenderMode().setValue(LowRamConfig.cloudsOff ? CloudRenderMode.OFF : CloudRenderMode.FAST);
        o.getEntityShadows().setValue(!LowRamConfig.entityShadowsOff);

        o.getMipmapLevels().setValue(LowRamConfig.fastGraphics ? 0 : 2);
        o.getBiomeBlendRadius().setValue(LowRamConfig.fastGraphics ? 0 : 2);
    }

    // Очистку делаем ТОЛЬКО когда игра на паузе или в меню — так не бывает микро-фризов
    private void onTick(MinecraftClient client) {
        if (!LowRamConfig.autoGc) return;
        if (++tickCounter < 200) return; // проверка раз в ~10 сек
        tickCounter = 0;

        Screen s = client.currentScreen;
        boolean safe = s instanceof TitleScreen || s instanceof GameMenuScreen || s instanceof LowRamScreen;
        if (!safe) return;

        long now = System.currentTimeMillis();
        if (now - lastGc < 60_000) return;

        Runtime rt = Runtime.getRuntime();
        long used = rt.totalMemory() - rt.freeMemory();
        if (used * 100 / rt.maxMemory() >= LowRamConfig.gcThresholdPercent) {
            System.gc();
            lastGc = now;
        }
    }
}
