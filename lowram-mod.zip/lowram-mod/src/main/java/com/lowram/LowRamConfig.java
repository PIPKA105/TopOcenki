package com.lowram;

import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public class LowRamConfig {
    public static int viewDistance = 6;
    public static int simDistance = 5;
    public static double entityDistance = 0.5;
    public static int maxFps = 60;
    public static int particles = 2;          // 0 все, 1 меньше, 2 минимум
    public static boolean fastGraphics = true;
    public static boolean cloudsOff = true;
    public static boolean entityShadowsOff = false;
    public static boolean autoGc = true;      // очистка памяти только в меню/паузе (без фризов)
    public static int gcThresholdPercent = 70;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("lowram.properties");
    }

    public static void presetBalanced() {
        viewDistance = 8; simDistance = 6; entityDistance = 0.75; maxFps = 90;
        particles = 1; fastGraphics = true; cloudsOff = false; entityShadowsOff = false;
    }

    public static void presetExtreme() {
        viewDistance = 4; simDistance = 5; entityDistance = 0.5; maxFps = 60;
        particles = 2; fastGraphics = true; cloudsOff = true; entityShadowsOff = true;
    }

    public static void load() {
        Path p = path();
        if (!Files.exists(p)) { save(); return; }
        try (InputStream in = Files.newInputStream(p)) {
            Properties pr = new Properties();
            pr.load(in);
            viewDistance = Integer.parseInt(pr.getProperty("viewDistance", "" + viewDistance));
            simDistance = Integer.parseInt(pr.getProperty("simDistance", "" + simDistance));
            entityDistance = Double.parseDouble(pr.getProperty("entityDistance", "" + entityDistance));
            maxFps = Integer.parseInt(pr.getProperty("maxFps", "" + maxFps));
            particles = Integer.parseInt(pr.getProperty("particles", "" + particles));
            fastGraphics = Boolean.parseBoolean(pr.getProperty("fastGraphics", "" + fastGraphics));
            cloudsOff = Boolean.parseBoolean(pr.getProperty("cloudsOff", "" + cloudsOff));
            entityShadowsOff = Boolean.parseBoolean(pr.getProperty("entityShadowsOff", "" + entityShadowsOff));
            autoGc = Boolean.parseBoolean(pr.getProperty("autoGc", "" + autoGc));
            gcThresholdPercent = Integer.parseInt(pr.getProperty("gcThresholdPercent", "" + gcThresholdPercent));
        } catch (Exception e) {
            System.err.println("[LowRam] не удалось прочитать конфиг: " + e);
        }
    }

    public static void save() {
        try (OutputStream out = Files.newOutputStream(path())) {
            Properties pr = new Properties();
            pr.setProperty("viewDistance", "" + viewDistance);
            pr.setProperty("simDistance", "" + simDistance);
            pr.setProperty("entityDistance", "" + entityDistance);
            pr.setProperty("maxFps", "" + maxFps);
            pr.setProperty("particles", "" + particles);
            pr.setProperty("fastGraphics", "" + fastGraphics);
            pr.setProperty("cloudsOff", "" + cloudsOff);
            pr.setProperty("entityShadowsOff", "" + entityShadowsOff);
            pr.setProperty("autoGc", "" + autoGc);
            pr.setProperty("gcThresholdPercent", "" + gcThresholdPercent);
            pr.store(out, "LowRam config");
        } catch (Exception e) {
            System.err.println("[LowRam] не удалось сохранить конфиг: " + e);
        }
    }
}
