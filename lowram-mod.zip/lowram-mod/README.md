# LowRam (Fabric 1.21.1)

Сборка:
1. Установи JDK 21.
2. В папке проекта: `gradle build` (или `./gradlew build`, если есть wrapper).
3. Готовый мод: `build/libs/lowram-1.0.0.jar` -> в папку `mods`.

Нужен Fabric API.
Настройки (дальность, FPS, порог очистки) — константы в LowRamMod.java.
