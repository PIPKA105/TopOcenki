# LowRam (Fabric 1.21.1)
Сборка: gradle build -> build/libs/lowram-1.0.0.jar (нужен JDK 21 и Fabric API).
Кнопка "Оптимизация LowRam" — в левом верхнем углу главного меню.
Конфиг: config/lowram.properties
